import React from 'react'
import AddForm from './addForm'
import EditForm from './editForm'

function FormContainer() {
  return (
    <div>
      <AddForm />
    </div>
  )
}

export default FormContainer
