import HomePage from "./Components/Home";
import './App.css'

function App() {
  return (
    <div>
      <HomePage />
    </div>
  );
}

export default App;
